﻿using System;

namespace liczeniekwadratowej
{
    class Program
    {
        static void Main(string[] args)
        {
            double a=0, b=0, c=0,delta=0,x1=0,x2=0,x0=0,p_delta=0;
            Console.WriteLine("Podaj a:");
            a= double.Parse(Console.ReadLine());
            Console.WriteLine("Podaj b:");
            b = double.Parse(Console.ReadLine());
            Console.WriteLine("Podaj c:");
            c = double.Parse(Console.ReadLine());
            delta = (b * b) - (4 * a * c);
            if (delta > 0)
            {
                p_delta = Math.Pow(2, delta);
                x1 = (-b - p_delta) / (2 * a);
                x2 = (-b + p_delta) / (2 * a);
                Console.WriteLine("Pierwiastki równania wynoszą:"+x1+" , "+x2);
            }
            if (delta == 0)
            {
                x0 = (-b) / (2 * a);
                Console.WriteLine("Pierwiastek równania wynosi:" + x0);
            }
            if (delta < 0)
            {
                Console.WriteLine("Nie ma");
            }
            
        }
    }
}
