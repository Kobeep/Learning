﻿using System;

namespace zadanie1
{
    class Program
    {
        static void Main(string[] args)
        {
            float a = 0, b = 0, wynik = 0;
            String dzialanie;
            Console.WriteLine("Podaj pierwszą liczbę:");
            a=float.Parse(Console.ReadLine());
            Console.WriteLine("Podaj drugą liczbę:");
            b = float.Parse(Console.ReadLine());
            Console.WriteLine("Jakie działanie wykonać(wpisz znak):");
            dzialanie = Console.ReadLine();
            switch (dzialanie)
                {
                case "+" :
                    wynik = a + b;
                    break;
                case "*" :
                    wynik = a * b;
                    break;
                case "/" :
                    wynik = a / b;
                    break;
                case "-" :
                    wynik = a - b;
                    break;
            }
            Console.WriteLine("Wynik:"+wynik);
        }
    }
}
