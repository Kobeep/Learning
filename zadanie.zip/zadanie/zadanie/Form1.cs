﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zadanie
{
    public partial class Form1 : Form
    {
        Double la = 0, lb = 0, lc = 0, wynik = 0,delta =0,x1=0,x2=0,x0=0;

        public Form1()
        {
            InitializeComponent();
        }

        private void pobierz(object sender, EventArgs e)
        {
            la = Double.Parse(a.Text);
            lb = Double.Parse(b.Text);
            lc = Double.Parse(c.Text);
            delta = (lb * lb) - (4 * la * lc);
            delta_wynik.Text = "delta wynosi:" + delta.ToString();
            if (delta>0)
            {
                x1 = (-lb - Math.Sqrt(delta)) / (2 * la);
                x2 = (-lb + Math.Sqrt(delta)) / (2 * la);
                w_wynik.Text = "x1:" + x1.ToString() + "x2:" + x2.ToString();
            }
            else if(delta==0){
                x0 = (-lb)/(2*la);
                w_wynik.Text = "x0:" + x0.ToString();
            }
            else
                w_wynik.Text = "brak miejsc zerowych";

        }
    }
}
